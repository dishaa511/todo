const express = require('express');
const connectDB = require('./config/db');
var cors = require('cors');
const mongoose = require('mongoose');

const todos = require('./routes/api/todos');

const app = express();

// connectDB();
mongoose.connect("mongodb+srv://testUser:disha123456@cluster0-8fdqa.mongodb.net/test?retryWrites=true&w=majority");
mongoose
    .connection
    .on('error', (err) => {
        console.error(err);
        console.log('%s MongoDB connection error. Please make sure MongoDB is running.');
        process.exit();
    });


app.use(cors({ origin: true, credentials: true }));

app.use(express.json({ extended: false }));

app.get('/', (req, res) => res.send('Hello world!'));

app.use('/api/todos', todos);

const port = process.env.PORT || 8082;

app.listen(port, () => console.log(`Server running on port ${port}`));
