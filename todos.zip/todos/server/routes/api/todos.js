const express = require('express');
const router = express.Router();

const Todo = require('../../models/todo');
router.get('/test', (req, res) => res.send('todo route testing!'));

router.get('/', (req, res) => {
  todo.find()
    .then(todos => res.json(todos))
    .catch(err => res.status(404).json({ notodosfound: 'No todos found' }));
});

router.get('/:id', (req, res) => {
  todo.findById(req.params.id)
    .then(todo => res.json(todo))
    .catch(err => res.status(404).json({ notodofound: 'No todo found' }));
});

router.post('/', (req, res) => {
  // todo.create(req.body)
  //   .then(todo => res.json({ msg: 'todo added successfully' }))
  //   .catch(err => res.status(400).json({ error: 'Unable to add this todo' }));
  console.log(req.body)
  var TodoModel = new Todo(req.body);
  try {
    TodoModel.save(function (err, result) {
      console.log(err, result)
      if (err) {
        res.send({
          ...err,
          success: false
        })
      } else {
        var result = result;
        result.success = true;
        res.send(result)
      }
    })
  } catch (err) {
    console.log(err, 'ddqwdq')
  }

});

router.put('/:id', (req, res) => {
  todo.findByIdAndUpdate(req.params.id, req.body)
    .then(todo => res.json({ msg: 'Updated successfully' }))
    .catch(err =>
      res.status(400).json({ error: 'Unable to update the Database' })
    );
});

router.delete('/:id', (req, res) => {
  todo.findByIdAndRemove(req.params.id, req.body)
    .then(todo => res.json({ mgs: 'todo entry deleted successfully' }))
    .catch(err => res.status(404).json({ error: 'No such a todo' }));
});

module.exports = router;