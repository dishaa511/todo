import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import '../App.css';

class UpdatetodoInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isbn: '',
      description: '',
      published_date: '',
    };
  }

  componentDidMount() {
    // console.log("Print id: " + this.props.match.params.id);
    axios
      .get('http://localhost:8082/api/todos/'+this.props.match.params.id)
      .then(res => {
        // this.setState({...this.state, todo: res.data})
        this.setState({
          title: res.data.title,
          description: res.data.description,
          published_date: res.data.published_date,
        })
      })
      .catch(err => {
        console.log("Error from UpdatetodoInfo");
      })
  };

  onChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmit = e => {
    e.preventDefault();

    const data = {
      title: this.state.title,
      description: this.state.description,
      published_date: this.state.published_date,
    };

    axios
      .put('http://localhost:8082/api/todos/'+this.props.match.params.id, data)
      .then(res => {
        this.props.history.push('/show-todo/'+this.props.match.params.id);
      })
      .catch(err => {
        console.log("Error in UpdatetodoInfo!");
      })
  };


  render() {
    return (
      <div className="UpdatetodoInfo">
        <div className="container">
          <div className="row">
            <div className="col-md-8 m-auto">
              <br />
              <Link to="/" className="btn btn-outline-warning float-left">
                  Show todo List
              </Link>
            </div>
            <div className="col-md-8 m-auto">
              <h1 className="display-4 text-center">Edit todo</h1>
              <p className="lead text-center">
                  Update todo's Info
              </p>
            </div>
          </div>

          <div className="col-md-8 m-auto">
          <form noValidate onSubmit={this.onSubmit}>
            <div className='form-group'>
              <label htmlFor="title">Title</label>
              <input
                type='text'
                placeholder='Title of the todo'
                name='title'
                className='form-control'
                value={this.state.title}
                onChange={this.onChange}
              />
            </div>
            <br />

            <div className='form-group'>
            <label htmlFor="description">Description</label>
              <input
                type='text'
                placeholder='Describe this todo'
                name='description'
                className='form-control'
                value={this.state.description}
                onChange={this.onChange}
              />
            </div>

            <div className='form-group'>
            <label htmlFor="published_date">Published Date</label>
              <input
                type='date'
                placeholder='published_date'
                name='published_date'
                className='form-control'
                value={this.state.published_date}
                onChange={this.onChange}
              />
            </div>

            <button type="submit" className="btn btn-outline-info btn-lg btn-block">Update todo</button>
            </form>
          </div>

        </div>
      </div>
    );
  }
}

export default UpdatetodoInfo;