import React from 'react';
import { Link } from 'react-router-dom';
import '../App.css';

const Todocard = (props) => {
    const  todo  = props.todo;

    return(
        <div className="card-container">
            <div className="desc">
                <h2>
                    <Link to={`/show-todo/${todo._id}`}>
                        { todo.title }
                    </Link>
                </h2>
                <p>{todo.description}</p>
            </div>
        </div>
    )
};

export default Todocard;