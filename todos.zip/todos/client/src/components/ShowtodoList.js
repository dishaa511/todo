import React, { Component } from 'react';
import '../App.css';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Todocard from './todoCard';

class ShowtodoList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: []
    };
  }

  componentDidMount() {
    axios
      .get('http://localhost:8082/api/todos')
      .then(res => {
        this.setState({
          todos: res.data
        })
      })
      .catch(err =>{
        console.log('Error from ShowtodoList');
      })
  };


  render() {
    const todos = this.state.todos;
    console.log("Printtodo: " + todos);
    let todoList;

    if(!todos) {
      todoList = "there is no todo record!";
    } else {
      todoList = todos.map((todo, k) =>
        <Todocard todo={todo} key={k} />
      );
    }

    return (
      <div className="ShowtodoList">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <br />
              <h2 className="display-4 text-center">todos List</h2>
            </div>

            <div className="col-md-11">
              <Link to="/create-todo" className="btn btn-outline-warning float-right">
                + Add New todo
              </Link>
              <br />
              <br />
              <hr />
            </div>

          </div>

          <div className="list">
                {todoList}
          </div>
        </div>
      </div>
    );
  }
}

export default ShowtodoList;